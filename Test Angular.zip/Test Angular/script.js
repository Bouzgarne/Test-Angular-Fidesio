var app = angular.module("app",['angularUtils.directives.dirPagination']);

app.controller('mainCtrl', function($scope, $http){
    $http({
      method : 'GET',
      url : 'https://data.ratp.fr/api/records/1.0/search/?dataset=liste-des-commerces-de-proximite-agrees-ratp&rows=50&sort=code_postal&facet=tco_libelle&facet=code_postal'
    }).success(function(data){
      records = data['records'];      
      $scope.objects = records ;
      // $scope.pageSize = 10 ;
      // $scope.currentPage = 1 ;
      console.log('successs');
      console.log(records);
    }).catch(function(response){
      console.log('response', response);
    });    
  
});
// .filter('startFrom', function(){
//   return function(data, start){
//       return data.slice(start);
//   }
// });


